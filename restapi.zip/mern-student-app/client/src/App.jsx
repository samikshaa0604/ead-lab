import React, { useEffect, useState } from 'react';
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
});

export default function App() {
  const [form, setForm] = useState({ name: '', roll: '', branch: '' });
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchStudents = async () => {
    try {
      const res = await api.get('/students');
      setStudents(res.data);
    } catch (e) {
      console.error(e);
      setError('Failed to load students. Is the server running?');
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await api.post('/students', form);
      setForm({ name: '', roll: '', branch: '' });
      await fetchStudents();
    } catch (e) {
      setError(e?.response?.data?.error || 'Failed to add student');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 720, margin: '2rem auto', fontFamily: 'system-ui, Arial' }}>
      <h1>EAD Lab – Student Management (MERN)</h1>
      <form onSubmit={handleSubmit} style={{ display: 'grid', gap: '0.75rem', marginBottom: '1.5rem' }}>
        <input
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          required
        />
        <input
          name="roll"
          placeholder="Roll"
          value={form.roll}
          onChange={handleChange}
          required
        />
        <input
          name="branch"
          placeholder="Branch (e.g., CSE)"
          value={form.branch}
          onChange={handleChange}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Saving...' : 'Add Student'}
        </button>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <h2>Student List</h2>
      <ul>
        {students.map((s) => (
          <li key={s._id}>
            <strong>{s.name}</strong> — Roll: {s.roll} — Branch: {s.branch}
          </li>
        ))}
      </ul>
    </div>
  );
}
