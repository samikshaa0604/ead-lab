# EAD Lab – MERN Student Management (Question 14)

Minimal MERN app with:
- **Backend**: Express + MongoDB (Mongoose)
- **Frontend**: React (Vite) + Axios

## Prerequisites
- Node.js 18+
- MongoDB running locally on `mongodb://127.0.0.1:27017`

---
## Step-by-Step Setup

### 1) Start MongoDB
Ensure MongoDB is running (Windows Services or `mongod`).

### 2) Backend (server)
```bash
cd server
cp .env.example .env   # On Windows, just create .env with same values
npm install
npm run dev
```
It should print: `Server running on http://localhost:5000` and `Connected to MongoDB`.

Test in browser: http://localhost:5000/  -> should return JSON `{ status: 'OK', service: 'student-api' }`

### 3) Frontend (client)
Open a new terminal:
```bash
cd client
npm install
npm run dev
```
Open the URL shown (default `http://localhost:5173`). The form lets you add students and see the list.

---
## API Endpoints (Server)
- `POST /api/students`  Create a student. JSON body: `{ "name": "A", "roll": "22IT001", "branch": "CSE" }`
- `GET /api/students`   List all students.

---
## Common Issues
- **CORS / Network error**: Ensure server is on port 5000 and client uses `http://localhost:5000` base URL (see `App.jsx`).
- **Mongo not connected**: Update `MONGODB_URI` in `.env` if your instance differs.
- **Port in use**: Change `PORT` in `.env` or Vite dev server port in `vite.config.js`.

---
## Folder Structure
```
mern-student-app/
  server/
    server.js
    models/Student.js
    package.json
    .env.example
  client/
    index.html
    vite.config.js
    package.json
    src/
      main.jsx
      App.jsx
```
